const ApiURL = 'http://localhost:1088';

const PLANTILLA_ITEM = `
    <div class="card">
        <img class="card-img-top" src="{imagen}" alt="Card image cap">
        <div class="card-body">
            <div class="d-flex flex-column">
                <h5 class="card-title">{precio} MXN</h5>  
                                          
            </div>
            <p class="card-text">{titulo}</p>
            <h6 class="card-subtitle">{tipo}</h6>    
        </div>
    </div>
`;

let pageSize = 10;
let currentPage = 1;
let totalPages = 1;

var toastTime = 5000;

//evento que se ejecuta cuando la pagina termina de cargar.
window.onload = function() {
    
    //Lo primero que hacemos es obtener todos los datos usando la API
    getData();
	getEmails();

    //asignamos el evento de presionar tecla a una funcion que nos servira para saber si presionaron enter
    document.querySelectorAll('input')
    .forEach((function(x){ 
        x.addEventListener('keyup', e => {
            catchEnter(e);
        });
    }));

}

//muestra el preloader que ocupa toda la pagina
function showPreloader()
{
    document.querySelector('#preloader').style.display = '';
}

//oculta el preloader que ocupa toda la pagina
function hidePreloader()
{
    document.querySelector('#preloader').style.display = 'none';
}

function getData(){

        showPreloader();

        //El metodo o funcion o endpoint de la API que vamos usar
        const webMethod = ApiURL + "/anuncios";

        //El objeto que nos va a permitir conectarnos a la API
        const xhttp = new XMLHttpRequest();

        //El metodo que va a estar "escuchando" cuando la peticion a la API nos devuelva alguna respuesta.
        xhttp.onreadystatechange = function() {

                //Si la peticion ya termino (readyState == 4) y regreso una respuesta correcta (status == 200)
                if (this.readyState == 4 && this.status == 200) {

                    //Si no regreso datos, nos salimos sin hacer nada
                    if(!xhttp.response){ return; }

                    //Obtenemos los datos del response.
                    let response = xhttp.response;

                    //Los datos vienen como texto plano, 
                    //asi que los convertimos en un arreglo de objetos para poder trabajar con ellos
                    response = JSON.parse( response );

                    //guardamos los datos en memoria para poder acceder a ellos mas tarde
                    $('body').data('datosCompletos', response);
                    $('body').data('datosFiltrados', response);
                   
                    //generamos los controles de paginacion
                    generarPaginacion( response.length );                                       

                    //por default mostramos la pagina uno
                    //(Ya antes hemos validado que haya traido datos)
                    showPage(1);
                   
                }

                //Si la peticion ya termino (readyState == 4) y regreso una respuesta incorrecta (status == 0)
                if (this.readyState == 4 && this.status == 0) {
                    //Show an error toast
                    /* var error = {};
                    error.statusText = ErrorMessages.NoConnection;
                    ToastError(error); */
                }

                //Si la peticion ya termino (readyState == 4) sin importar la respuesta
                if (this.readyState == 4)
                {
                    //Hide preloader
                    hidePreloader();
                }

        };

        //Abrimos la conexion con la API 
        //(el primer parametro es el tipo de peticion, el segundo es la url, y el tercer parametro indica si la peticion es sincrona o asincrona)
        xhttp.open("GET", webMethod, true);

        //Enviamos la peticion a la API
        xhttp.send(''); 
}

function enviarEmail(){

    let nombre = document.querySelector('#txtEmailNombre').value;
    let email = document.querySelector('#txtEmailEmail').value;
    let mensaje = document.querySelector('#txtEmailMensaje').value;

    showPreloader();

    //El metodo o funcion o endpoint de la API que vamos usar
    const webMethod = ApiURL + "/Create_Correo";

    //El objeto que nos va a permitir conectarnos a la API
    const xhttp = new XMLHttpRequest();

    //El metodo que va a estar "escuchando" cuando la peticion a la API nos devuelva alguna respuesta.
    xhttp.onreadystatechange = function() {

            //Si la peticion ya termino (readyState == 4) y regreso una respuesta correcta (status == 200)
            if (this.readyState == 4 && this.status == 200) {

               if (this.readyState == 4 && this.status == 200) {

                $('#modalEnviarEmail').modal('toggle');
                ToastSuccess('Email enviado con exito');
                
            }
                
            }

            //Si la peticion ya termino (readyState == 4) y regreso una respuesta incorrecta (status == 0)
            if (this.readyState == 4 && (this.status == 0 || this.status == 400 || this.status == 404)) {
                //Mostramos el error
                var error = {};
                error.statusText = this.statusText;
                ToastError(error);
            }

            //Si la peticion ya termino (readyState == 4) sin importar la respuesta
            if (this.readyState == 4)
            {
                //Hide preloader
                hidePreloader();
            }

    };

    //Los datos que vamos a enviar en formato JSON
    var formDataSend = {
        "idCorreo": Math.floor(Math.random() * 100001),
        "nombre": nombre,
        "correo": email,
        "mensaje": mensaje
    }

    
    //Abrimos la conexion con la API 
    //(el primer parametro es el tipo de peticion, el segundo es la url, y el tercer parametro indica si la peticion es sincrona o asincrona)
  xhttp.open("POST", webMethod, true);
  //La cabecera que indica que el contenido sera JSON
    xhttp.setRequestHeader('Content-Type', 'application/json');


    //Enviamos la peticion a la API junto con los datos
    xhttp.send(JSON.stringify(formDataSend)); 
}

function generarPaginacion( numDatos ){

    let numPages = numDatos / pageSize;

    numPages = Math.ceil(numPages);

    totalPages = numPages;

    let pagesHTML = `<div id="pageData"><li class="page-item disabled">
                        <span id="currentPage" class="page-link" tabindex="-1">page ${ 1 }/${ numPages }</span>
                    </li></div>`;

    for(i=0; i< numPages; i++){

        pagesHTML += `<li class="page-item"><a class="page-link" href="javascript:showPage(${i + 1})">${ i + 1 }</a></li>`;

    }

    document.querySelector('.pagination').innerHTML = pagesHTML;

}

function generarTarjeta( datos ) {

    let itemHTML = PLANTILLA_ITEM;

    itemHTML = itemHTML.replace('{titulo}', datos.titulo);
    itemHTML = itemHTML.replace('{imagen}', './images/productos/' + datos.imagen);
    itemHTML = itemHTML.replace('{tipo}', datos.tipo);
    itemHTML = itemHTML.replace('{precio}', datos.precio);

    document.querySelector('.product-items').innerHTML += itemHTML;

}

function showPage( page ){
    
    //ponemos la variable global que nos va a servir para validaciones futuras
    currentPage = page;

    //Vaciamos la lista de productos para que no muestre ninguno
    document.querySelector('.product-items').innerHTML = '';

    //Removemos el boton de "pagina siguiente"
    document.querySelector('#nextPageButton') && document.querySelector('#nextPageButton').remove();

    //Removemos el boton de "pagina anterior"
    document.querySelector('#prevPageButton') && document.querySelector('#prevPageButton').remove();
        
    const datos = $('body').data('datosFiltrados');

    //hacemos el calculo para saber cuantos productos vamos a mostrar.
    //Si hay menos productos que el tamaño de pagina, pues los mostramos todos
    //Si no, entonces mostramos solo los del tamaño de la pagina
    let bottom = (page * pageSize) - pageSize;
    let top = (page * pageSize);

    if(datos.length < top){
        top = datos.length;
    }

    //Aqui llamamos a la funcion para generar el "card" de cada producto y mostrarlo en pantalla
    for(i=bottom; i<top; i++){

        generarTarjeta(datos[i]);

    }

    document.querySelector('#currentPage').innerHTML = `page ${ currentPage }/${ totalPages }`;

    //Revisamos si debemos agregar el boton de pagina siguiente
    if(currentPage < totalPages){
        let pagesHTML = `<li id="nextPageButton" class="page-item">
                            <a class="page-link" href="javascript:showPage(${currentPage + 1})">Siguiente</a>
                        </li>`
        document.querySelector('.pagination').innerHTML += pagesHTML;
    }else{
        let pagesHTML = `<li id="nextPageButton" class="page-item disabled">
                            <span class="page-link">Siguiente</span>
                        </li>`
        document.querySelector('.pagination').innerHTML += pagesHTML;
    }

    //Revisamos si debemos agregar el boton de pagina anterior
    if(currentPage > 1){
        let pagesHTML = `<li id="prevPageButton" class="page-item">
            <a class="page-link" href="javascript:showPage(${currentPage - 1})">Anterior</a>
        </li>`
        document.querySelector('#pageData').innerHTML += pagesHTML;
    }else{
        let pagesHTML = `<li id="prevPageButton" class="page-item disabled">
            <span class="page-link">Anterior</span>
        </li>`
        document.querySelector('#pageData').innerHTML += pagesHTML;
    }

}

function filtrarResultados(){

    const datos = $('body').data('datosCompletos');

    const titulo = document.querySelector('#txtAnuncio').value;    
    let tipo = document.querySelector('#txtTipo').value;
    let precioIni = document.querySelector('#txtPrecio01').value;
    let precioFin = document.querySelector('#txtPrecio02').value;

    if(tipo === 'Todos'){ tipo = '' }
    if(precioIni === ''){ precioIni = 0 }
    if(precioFin === ''){ precioFin = 0 }

    const datosFiltrados = datos.filter( dato => 
        dato.titulo.toUpperCase().includes(titulo.toUpperCase()) && dato.tipo.toUpperCase().includes(tipo.toUpperCase()) && (dato.precio >= precioIni || precioIni === 0)  && (dato.precio <= precioFin || precioFin === 0)
    );

    $('body').data('datosFiltrados', datosFiltrados);

    generarPaginacion( datosFiltrados.length );

    showPage(1);
   
}

function catchEnter( e ){

    if( e.keyCode == 13 ){
        filtrarResultados();
    }

}

function ToastSuccess(texto)
{
    var Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: toastTime
    });
    
    Toast.fire({
        icon: 'success',
        title: texto
    });
}


function ToastError(e)
{
    var Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: toastTime
    });

    var textoError = '';

    if(e.responseJSON)
    {
        if(e.responseJSON.error)
        {
            textoError = e.responseJSON.error;
        }

        if(e.responseJSON.errmsg)
        {
            textoError = e.responseJSON.errmsg;
        }

        if(e.responseJSON.msg)
        {
            textoError = e.responseJSON.msg;
        }
        
    }

    if(!textoError)
    {
        if(e.statusText)
        {
            textoError = e.statusText;
        }
    }   

    if(e.message)
    {
        textoError = e.message;
    }  

    Toast.fire({
        icon: 'error',
        title: textoError
    });
}

function getEmails(){

    showPreloader();

    document.querySelector('#tableEmailList').innerHTML = '';

    //El metodo o funcion o endpoint de la API que vamos usar
    const webMethod = ApiURL + "/enviarEmail";

    //El objeto que nos va a permitir conectarnos a la API
    const xhttp = new XMLHttpRequest();

    //El metodo que va a estar "escuchando" cuando la peticion a la API nos devuelva alguna respuesta.
    xhttp.onreadystatechange = function() {

            //Si la peticion ya termino (readyState == 4) y regreso una respuesta correcta (status == 200)
            if (this.readyState == 4 && this.status == 200) {

                //Si no regreso datos, nos salimos sin hacer nada
                if(!xhttp.response){ return; }

                //Obtenemos los datos del response.
                let response = xhttp.response;

                //Los datos vienen como texto plano, 
                //asi que los convertimos en un arreglo de objetos para poder trabajar con ellos
                response = JSON.parse( response );
                              
                for(i=0;i<response.length;i++){
                    let tableRow = `<tr>                    
                    <td>${response[i].nombre}</td>
                    <td>${response[i].correo}</td>
                    <td>${response[i].mensaje}</td>
                  </tr>`;
                  document.querySelector('#tableEmailList').innerHTML += tableRow;
                }
               
            }

            //Si la peticion ya termino (readyState == 4) y regreso una respuesta incorrecta (status == 0)
            if (this.readyState == 4 && this.status == 0) {
                //Show an error toast
                /* var error = {};
                error.statusText = ErrorMessages.NoConnection;
                ToastError(error); */
            }

            //Si la peticion ya termino (readyState == 4) sin importar la respuesta
            if (this.readyState == 4)
            {
                //Hide preloader
                hidePreloader();
            }

    };

    //Abrimos la conexion con la API 
    //(el primer parametro es el tipo de peticion, el segundo es la url, y el tercer parametro indica si la peticion es sincrona o asincrona)
    xhttp.open("GET", webMethod, true);

    //Enviamos la peticion a la API
    xhttp.send(''); 
}